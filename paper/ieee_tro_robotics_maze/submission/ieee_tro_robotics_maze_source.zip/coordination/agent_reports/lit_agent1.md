# Literature Agent 1 Report

## Summary Stats
- candidate_count: 35
- year_range: 2021-2025
- peer_reviewed_count: 35
- peer_reviewed_ratio: 35/35 (100.00%)
- venue_mix: journal_or_other=33, conference=2

## Notes
- All entries were DOI-resolved and metadata-verified (title/year/venue/type).
- All included items satisfy year >= 2021.
- Preprints were allowed by task spec but not required for this pool; this set is entirely journal/conference proceedings.
