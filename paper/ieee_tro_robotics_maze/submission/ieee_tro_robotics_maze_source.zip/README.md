# IEEEtran Journal Template

Build:
- `make pdf` (requires latexmk)
- Output: `main.pdf`

Edit:
- `main.tex` for title, authors, abstract, keywords
- `sections/*.tex` for content
- `references.bib` for BibTeX entries
